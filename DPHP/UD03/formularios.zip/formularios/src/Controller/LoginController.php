<?php

namespace App\Controller;

use App\Form\LoginType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class LoginController extends AbstractController
{
    #[Route('/login', name: 'app_login')]
    public function index(Request $request): Response
    {
        // 1. Crear el formulario a partir de la clase LoginType
        $form = $this->createForm(LoginType::class);

        // 2. Procesar la solicitud HTTP (GET o POST)
        $form->handleRequest($request);

        // 3. Si el formulario fue enviado y es válido
        if ($form->isSubmitted() && $form->isValid()) {
            // Obtener los datos enviados
            $data = $form->getData();
            $usuario = $data['username'];
            $clave   = $data['password'];

            // Simular validación de usuario
            if ($usuario === 'admin' && $clave === '1234') {
                $this->addFlash('success', 'Inicio de sesión correcto');
                return $this->redirectToRoute('app_home'); // o a cualquier otra ruta
            } else {
                $this->addFlash('error', 'Usuario o contraseña incorrectos');
            }
        }

        // 4. Renderizar la vista y pasar el formulario
        return $this->render('login/index.html.twig', [
            'formulario' => $form->createView(),
        ]);
    }
}
