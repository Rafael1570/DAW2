<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_wdt/styles' => [[['_route' => '_wdt_stylesheet', '_controller' => 'web_profiler.controller.profiler::toolbarStylesheetAction'], null, null, null, false, false, null]],
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/xdebug' => [[['_route' => '_profiler_xdebug', '_controller' => 'web_profiler.controller.profiler::xdebugAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/rrhh/ejercicio4' => [[['_route' => 'app_rrhhapp_ejercicio4', '_controller' => 'App\\Controller\\Ejercicio4Controller::index'], null, null, null, false, false, null]],
        '/rrhh/empleados' => [[['_route' => 'app_rrhhapp_empleados', '_controller' => 'App\\Controller\\Ejercicio4Controller::empleados'], null, null, null, false, false, null]],
        '/empleado/nuevo' => [[['_route' => 'app_empleado_new', '_controller' => 'App\\Controller\\EmpleadosController::nuevo'], null, null, null, false, false, null]],
        '/operaciones' => [[['_route' => 'app_operaciones', '_controller' => 'App\\Controller\\OperacionesController::index'], null, null, null, false, false, null]],
        '/redireccion/controll' => [[['_route' => 'app_redireccion_controll', '_controller' => 'App\\Controller\\RedireccionControllController::index'], null, null, null, false, false, null]],
        '/panel' => [[['_route' => 'app_panel', '_controller' => 'App\\Controller\\RedireccionControllController::panel'], null, null, null, false, false, null]],
        '/normativa' => [[['_route' => 'app_normativa', '_controller' => 'App\\Controller\\RedireccionControllController::normativa'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/(?'
                        .'|font/([^/\\.]++)\\.woff2(*:98)'
                        .'|([^/]++)(?'
                            .'|/(?'
                                .'|search/results(*:134)'
                                .'|router(*:148)'
                                .'|exception(?'
                                    .'|(*:168)'
                                    .'|\\.css(*:181)'
                                .')'
                            .')'
                            .'|(*:191)'
                        .')'
                    .')'
                .')'
                .'|/r(?'
                    .'|rhh/empleados/departamento/([^/]++)(*:242)'
                    .'|esta/([^/]++)/([^/]++)(*:272)'
                .')'
                .'|/empleado/(\\d+)(*:296)'
                .'|/doble/([^/]++)(*:319)'
                .'|/porcentaje/([^/]++)(?:/([^/]++))?(*:361)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        98 => [[['_route' => '_profiler_font', '_controller' => 'web_profiler.controller.profiler::fontAction'], ['fontName'], null, null, false, false, null]],
        134 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        148 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        168 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        181 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        191 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        242 => [[['_route' => 'app_rrhhapp_empleados_departamento', '_controller' => 'App\\Controller\\Ejercicio4Controller::empleadosDepartamento'], ['nombre'], null, null, false, true, null]],
        272 => [[['_route' => 'app_resta', '_controller' => 'App\\Controller\\OperacionesController::resta'], ['a', 'b'], null, null, false, true, null]],
        296 => [[['_route' => 'app_empleado_show', '_controller' => 'App\\Controller\\EmpleadosController::show'], ['id'], null, null, false, true, null]],
        319 => [[['_route' => 'app_doble', '_controller' => 'App\\Controller\\OperacionesController::doble'], ['numero'], null, null, false, true, null]],
        361 => [
            [['_route' => 'app_porcentaje', 'porcentaje' => '10', '_controller' => 'App\\Controller\\OperacionesController::porcentaje'], ['numero', 'porcentaje'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
